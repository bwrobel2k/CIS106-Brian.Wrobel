#inputs
totalbonus = 0

#process
for counter in range(0,5):
  Lastname = str(input("What is your last name?"))
  Salary = float(input("What is your salary?"))
  if Salary >= 100000:
    bonusrate =.2
  elif Salary >= 50000:
    bonusrate = .15
  else:
    bonusrate = .1

  bonus = Salary * bonusrate
  totalbonus = totalbonus + bonus
  print("Hello, ", Lastname, "Your salary is:", Salary, "Your bonus is:", bonus)


#output
print("The total bonuses paid out is: $", totalbonus)

