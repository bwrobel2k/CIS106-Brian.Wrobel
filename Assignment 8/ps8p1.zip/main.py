#inputs

Beginningvalue = int(input("Enter the beginning slaray?"))
Interestrate = float(input("Enter the interest rate?"))
year = 0
returntotal=0
#process

for counter in range(0,5):
  year = year +1
  print("Current year",year)
  print("Beginning Value: $",Beginningvalue)
  returnn = Beginningvalue * Interestrate
  returntotal = returntotal + returnn
  Endingvalue = Beginningvalue + returnn
  print("Ending value: $",Endingvalue)
  Beginningvalue = Endingvalue

#output
print("Total interest earned: $",returntotal)
  