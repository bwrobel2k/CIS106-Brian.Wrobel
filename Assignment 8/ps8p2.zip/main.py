firstnumber = 1
secondnumber = 1
#process
for counter in range(0,20):
  print(firstnumber)
  nextnumber = firstnumber + secondnumber
  firstnumber = secondnumber
  secondnumber = nextnumber
  