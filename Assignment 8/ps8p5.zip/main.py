file =  open("data1","r")
lname = str(file.readline().rstrip('\n'))
numberofstudents = 0

while lname != "":
  print("The students last name:                 ",lname)
  district = str(file.readline().rstrip('\n'))
  creditstaken = int(file.readline())
  print("The amount of credits taken by student: ",creditstaken)
  if district == "I":
    tuitioncost = 250.00
  else:
    tuitioncost = 500.00

  tuitionowed = creditstaken * tuitioncost
  print("The tuition owed by student:            ",tuitionowed)
  
  lname = str(file.readline().rstrip('\n'))
  numberofstudents += 1

print("The number of students:                 ",numberofstudents)



