#inputs
partnumber = int(input("What is the part number you are looking for?"))
quanity = int(input("How many of that part do you want?"))

#process
if partnumber == 99:
  unitcost = 2
elif partnumber == 10 or partnumber == 55:
  unitcost = 1
elif partnumber == 80 or partnumber == 70:
  unitcost = 3
else:
  unitcost = 5

#output
print("Your partnumber was: ", partnumber)
print("Your cost per unit is: $", unitcost)
print("Your total cost is: $", unitcost * quanity)