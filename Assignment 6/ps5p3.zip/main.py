#input
principle = int(input("What is the principle amount you are depositing?"))
years = int(input("How many years will you deposit for?"))

#process
if principle > 100000 and years == 5:
  intrestrate = .06
elif principle >= 50000 and years == 10:
  intrestrate = .05
elif principle >= 50000 and years == 5:
  intrestrate = .04
else:
  intrestrate = .02

#output
print("Your deposited amount is: $", principle)
print("Your intrest rate is: ", intrestrate * 100)
print("Your estimated intrest earning in the first year is: $", principle*intrestrate)