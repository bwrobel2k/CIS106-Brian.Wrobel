#inputs
quanity = int(input("How many tickest do you want?"))

#process
if quanity >= 25:
  priceperticket = 50
elif quanity >= 10:
  priceperticket = 60
elif quanity >= 5:
  priceperticket = 70
else:
  priceperticket = 75

#output
print("The number of tickets you bought: ",quanity)
print("The price per ticket: $",priceperticket)
print("The total price: $",quanity*priceperticket)