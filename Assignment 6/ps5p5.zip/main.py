#inputs
lastname = str(input("What is your last name?"))
salary = float(input("What is your salary?"))
joblevel = int(input("What is your job level?"))
#process
if joblevel >= 10:
  bonus = .25
elif joblevel >=5:
  bonus = .2
else:
  bonus = .1
  
#output
print("Hello ", lastname, "your bonus for this year is: $", salary * bonus)