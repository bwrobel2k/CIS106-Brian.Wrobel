#inputs
amountofwidgets = int(input("How many widgets are you ordering?"))

#process
if amountofwidgets > 10000:
  price = 10
elif amountofwidgets>= 5000:
  price = 20
else:
  price = 30
tax = .07
extendedprice = amountofwidgets * price
#output
print("Your extended price is: $", extendedprice)
print("Your tax is: 7%")
print("Your total is: $", extendedprice * tax + extendedprice)