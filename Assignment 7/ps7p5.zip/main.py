#inputs
totaldiscount = 0
cont = str(input("Would you like to continue?"))
while cont == "Yes":
  quanity = int(input("How many items are you purchasing?"))
  price = int(input("What is the price per item?"))
  extendedprice = quanity * price
  if extendedprice > 10000:
    discount = .25
  else:
    discount = .1
  total = extendedprice - (extendedprice * discount)
  print("Your extended price is: $",extendedprice)
  print("Your discount amount is: $",extendedprice * discount)
  print("Your total is: $", total)
  totaldiscount = (extendedprice * discount) + totaldiscount
  cont = str(input("Would you like to continue?"))
#ouputs
print("The amount of money saved is: $",totaldiscount)  