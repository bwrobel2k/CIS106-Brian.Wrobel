#process
number = 1
print(number)

while number<25:
  number += 2
  print(number)
  