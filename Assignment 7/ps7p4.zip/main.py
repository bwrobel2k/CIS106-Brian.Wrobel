#inputs
cont = str(input("Would you like to continue?"))
numberofemployees = 0
totalgrosspay = 0
#process
while cont == "Yes":
  lname = str(input("What is your last name?"))
  hours = int(input("How many hours did you work?"))
  payrate = float(input("How much do you get paid per hour?"))
  if hours > 40:
    overtime = hours - 40
    hours = 40
    grosspay = (hours * payrate) + (overtime * payrate * 1.5)
  else:
    grosspay = hours * payrate
    
  print("Hello: ",lname)
  print("You pay this week is: $", grosspay)
  numberofemployees += 1
  totalgrosspay = grosspay + totalgrosspay

  cont = str(input("Would you like to continue?"))

  #output
print("The sum of all gross pays is: $",totalgrosspay)
print("The number of employees: ",numberofemployees)
print("The average gross pay is: $",totalgrosspay/numberofemployees)
