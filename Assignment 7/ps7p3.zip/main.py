#input
cont = str(input("Would you like to continue?"))
numberofstudents=0
#process
while cont == "Yes":
  lname = str(input("What is your last name?"))
  exam1 = int(input("What is the score on your first exam?"))
  exam2 = int(input("What is the score on your second exam?"))
  average = (exam1 + exam2)/2
  numberofstudents += 1

  
  print("Hello, ",lname)
  print("Your average score was: ",average)
  print("The number of students data: ",numberofstudents)

  
  cont = str(input("Would you like to continue?"))
#ouputs

# end of program