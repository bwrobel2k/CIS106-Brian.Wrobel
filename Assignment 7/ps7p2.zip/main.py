#inputs
startingnumber = int(input("What number do you want to start with?"))
increment = int(input("What number would you like to increase by?"))
endingnumber = int(input("What number do you want to end with?"))

#process
while startingnumber < endingnumber:
  startingnumber = startingnumber + increment
  print(startingnumber)