continuee = str(input("Would like to use the program? (y/n)"))
inputs = 0
def mpgCalc(milestraveled,gallons):
  mpg= milestraveled/gallons
  return mpg
  





while continuee == "y":
  city = str(input("City is was your destination?"))
  gallons = int(input("How many gallons of gas did you use? "))
  milestraveled = int(input("How many miles did you travel? "))
  mpg= mpgCalc(milestraveled,gallons)
  inputs += 1
  print("Your destination city is :",city)
  print("The miles traveld is     :",milestraveled)
  print("The miles per galon is   :",mpg)
  continuee = str(input("Would like to use the program? (y/n)"))


print("The number of entries made  :",inputs)

  