continuee = str(input("Would you like to continue the program? (y/n) "))
totalgrosspay = 0
def Payrate(jobcode):
  if jobcode == "J":
    payrate = 50
  elif jobcode == "A":
    payrate = 30
  elif jobcode == "L":
    payrate = 25
  else:
    print("Entered an incorrect job code.")
    jobcode = str(input("What is your job code? (J/A/L)"))
    payrate = Payrate(jobcode)
  return payrate
    



while continuee == "y":
  lname = str(input("What is your last name?"))
  jobcode = str(input("What is your job code? (J/A/L)"))
  payrate = Payrate(jobcode)
  hours = int(input("How many hours did you work?"))
  if hours > 40:
    overtime = hours-40
    grosspay = (40 * payrate) + (overtime * (payrate * 1.5))
  else:
    grosspay = hours * payrate

  totalgrosspay = totalgrosspay + grosspay
  print(lname,", your grosspay is : $",grosspay)
  print("")
  continuee = str(input("Would you like to continue the program? (y/n) "))

print("The total grosspay is : $",totalgrosspay)

  
    
  