continuee = str(input("Do you want this program to continue?"))

def Process(qty, price):
  Extprice = qty*price
  if Extprice > 10000:
    discount = Extprice * .1
    newExtprice = Extprice - discount
  else:
    discount = 0
    newExtprice = Extprice

  print("The amount of items:     ",qty)
  print("Price Per Item:         $",price)
  print("Your extended price it: $",newExtprice)


while continuee == "Yes":
  qty = int(input("Enter quantity: "))
  price = int(input("Enter a price: "))
  Extprice= Process(qty,price)
  continuee = str(input("Do you want this program to continue?"))
  
