continuee = str(input("Would you like to continue the program? (y/n)"))
totaltutionowed = 0
def Tutioncalculator(districtcode,amountofcredits):
  costpercredithour = 0
  if districtcode == "I":
    costpercredithour = 250
  elif districtcode == "O":
    costpercredithour = 550
  else:
    print("That is not a valid district code. (I/O)")
    districtcode = str(input("What is the students district code?"))
    tutionowed = Tutioncalculator(districtcode, amountofcredits)

  tutionowed = costpercredithour * amountofcredits
  return tutionowed
    
  
  





while continuee == "y":
  lname = str(input("What is the students last name?"))
  districtcode = str(input("What is the students district code?"))
  amountofcredits = int(input("How many credits is the student taking?"))
  tutionowed = Tutioncalculator(districtcode, amountofcredits)
  totaltutionowed = totaltutionowed + tutionowed
  print(lname,", the amount of money owed for tuition is: $",tutionowed)



  
  continuee = str(input("Would you like to continue the program? (y/n)"))



print("Total tution owned by all students entered: $",totaltutionowed)