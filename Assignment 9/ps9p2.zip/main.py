continuee = str(input("Would like to continue? (y/n) "))
players = 0
def Battingaverage(hits, bats):
  print(lname,"'s batting average is : ", hits/bats)
  
while continuee == "y":
  lname = str(input("What is the players last name?"))
  hits = int(input("How many hits did they get?"))
  bats = int(input("How many bats did they get?"))
  players += 1
  Battingaverage(hits, bats)
  print("Players entered           : ", players)
  print("")
  continuee = str(input("Would like to continue? (y/n) "))
  



