#inputs
bookamount = int(input("How many books are you buying? "))
bookprice = float(input("What is the price of the book? "))

#process
booktotal = bookamount * bookprice

if booktotal <= 50:
  shipping = 25
else:
  shipping = 0

total = booktotal + shipping

#outputs
print("Your order is: $", booktotal)
print("Your shipping charge is: $", shipping)
print("Your total is: $", total)
