#inputs
item = input(str("Which item do you choose, A or B? "))
quanity = int(input("How many of this item do you want?"))

#process
if item == "A":
  unitprice = 10
else:
  unitprice = 20
  item = "B"

extendedprice = (unitprice * quanity)
#outputs
print("Your item was", item)
print("Your unitprice was", unitprice)
print("Your extended price is", extendedprice)
