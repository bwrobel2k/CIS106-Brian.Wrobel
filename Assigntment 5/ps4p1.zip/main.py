#inputs
quanity = int(input("Enter the quanity of product: "))

#process
if quanity >= 1000:
  unitprice = 3
else:
  unitprice = 5

extendedprice = (unitprice * quanity)
tax = extendedprice * .07
finalprice = extendedprice + tax
#outputs
print("The amount of product is: ", quanity)
print("The unit price is: $", unitprice)
print("The extended price is: $", extendedprice)
print("The tax is: $", tax)
print("The final price is: $", finalprice)
