#inputs
lname = str(input("What is your last name?"))
numberofdependents = int(input("How many dependents do you have?"))
grossincome = int(input("What is your grossincome?"))

#process
adjustedgrossincome = (grossincome - numberofdependents) * 12000

if adjustedgrossincome >= 50000:
  taxrate = .2
else:
  taxrate = .1

incometax = adjustedgrossincome * taxrate

if incometax <= 0:
  incometax = 100
else:
  incometax = adjustedgrossincome * taxrate

#output
print("Hello ", lname)
print("Your grossincome is $", grossincome)
print("Your number of dependents is ", numberofdependents)
print("Your adjusted gross income is $", adjustedgrossincome)
print("Your income tax is $", incometax)
