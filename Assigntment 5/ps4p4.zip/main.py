#inputs
item = str(input("What appliance do you choose?"))
costofitem = int(input("What is the cost of the appliance?"))

#process
if costofitem >= 1000:
  warranty = costofitem * .1
else:
  warranty = costofitem * .05

total = costofitem + warranty

#outputs
print("The appliance you chose: ", item)
print("The cost of the the appliacnce: $", costofitem)
print("The cost of the warranty: $", warranty)
print("The total cost of the appliance: $", total)
