#inputs
fixedcosts = float(input("Enter fixed costs: "))
priceperunit = float(input("Enter price per unit: "))
costperunit = float(input("Enter cost per unit: "))

#process
breakeven = (priceperunit - costperunit) / fixedcosts

#output
print("Breakeven point: ", breakeven)
