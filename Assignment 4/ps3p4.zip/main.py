#inputs
fname = str(input("Enter your first name: "))
stepswalked = int(input("How many steps have you walked today? "))

#process
caloriesburned = stepswalked * .25

#output
print(f"Hello {fname}! You have burned {caloriesburned} calories today.")