#inputs
mealprice = int(input("Enter the price of the meal: "))

#process

#output
print("With %15 Tip: ")
print("Total: ", mealprice)
print("Tip: ", mealprice * .15)
print("Total with Tip: ", (mealprice * .15) + mealprice)

print("")

print("With %18 Tip: ")
print("Total: ", mealprice)
print("Tip: ", mealprice * .18)
print("Total with Tip: ", (mealprice * .18) + mealprice)

print("")

print("With 20% Tip: ")
print("Total: ", mealprice)
print("Tip: ", mealprice * .20)
print("Total with Tip: ", (mealprice * .20) + mealprice)
