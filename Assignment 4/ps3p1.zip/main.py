#inputs
firstexam = float(input("Enter your first exam points"))
secondexam = float(input("Enter your second exam points"))

#process
total = (firstexam * .6) + (secondexam * .4)
#output
print("Your total exam points are", total) 