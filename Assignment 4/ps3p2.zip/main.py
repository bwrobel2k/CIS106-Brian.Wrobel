#inputs
pricepershare = float(input("Enter your cost per share: "))
quanityofstock = float(input("Enter your amount of stock: "))
currentstockprice = float(input("Input the current stock price: "))
#process
total = (currentstockprice - pricepershare) * quanityofstock
#output
print("You currently have made $", total)
